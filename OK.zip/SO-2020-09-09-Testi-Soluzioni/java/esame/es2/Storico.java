package esame.es2;

public class Storico {
	
    private int cambirepentini = 0;

    public synchronized void incrementaCambiRepentini() {
        this.cambirepentini++;
    }

    public synchronized int getCambiRepentini() {
        return this.cambirepentini;
    }
	
}