package esame.es2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;

public class Esercizio2 {

    public static void main(String args[]) {

        DatiAzionari datoAzionario = new DatiAzionari();

        BufferedReader stdin = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Inserire il nome dell'indice:");
        String indice = null;

        try {
            indice = stdin.readLine();
        } catch (IOException e) {
            e.printStackTrace();
        }

        datoAzionario.setIndice(indice);
        RecuperaDati rD = new RecuperaDati(datoAzionario);
        rD.start();

        // creazione della PipedStream per collegare Main e AvvisaConsumatori
        PipedInputStream pis = new PipedInputStream();

        PipedOutputStream pos = null;
        try {
            pos = new PipedOutputStream(pis);
        } catch (IOException e) {
            e.printStackTrace();
            System.exit(-1);
        }
        ObjectOutputStream oos = null;
        try {
            oos = new ObjectOutputStream(pos);
        } catch (IOException e) {
            e.printStackTrace();
        }

        AvvisaConsumatori aC = new AvvisaConsumatori(pis);
        Thread taConsumatori = new Thread(aC);
        taConsumatori.start();

        int valore = 0;

        for (int i = 0; i < 15; i++) {
            try {
                Thread.currentThread().sleep(7000);
            } catch (InterruptedException ex) {
                ex.printStackTrace();
            }
            valore = datoAzionario.getValore();
            System.out.println("Main--- indice:" + datoAzionario.getIndice() + "  valore: " + valore);
            // differenza in valore assoluto
            if (valore > 70 || valore < 30) {
                Warning warning = null;
                if (valore < 30) {
                    warning = new Warning("ribasso eccessivo", valore);
                } else {
                    warning = new Warning("rialzo eccessivo", valore);
                }
                try {
                    oos.writeObject(warning);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        
        // termino
        rD.terminaThread();

        // Invio oggetto di fine
        Warning fine = new Warning("fine", valore);

        try {
            oos.writeObject(fine);
        } catch(IOException e) {
            e.printStackTrace();
        }
        // attendo la terminazione del thread
        try {
            rD.join();
            taConsumatori.join();
        } catch (InterruptedException e) {} 
    }

}