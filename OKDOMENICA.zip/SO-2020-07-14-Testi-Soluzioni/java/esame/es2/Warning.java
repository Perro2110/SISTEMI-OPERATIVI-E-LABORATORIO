package esame.es2;

import java.io.Serializable;

public class Warning implements Serializable {
    
    private String message = null;
    private int valore = 0;

    public Warning(String message, int valore) {
        this.message = message;
        this.valore = valore;
    }

    public String getMessage() {
        return message;
    }

    public int getValore() {
        return valore;
    }

}