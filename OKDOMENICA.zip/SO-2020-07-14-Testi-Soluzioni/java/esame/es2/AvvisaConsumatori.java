package esame.es2;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.PipedInputStream;
import java.nio.channels.Pipe;
import java.util.concurrent.atomic.AtomicBoolean;

public class AvvisaConsumatori implements Runnable {

    private AtomicBoolean isRunning = new AtomicBoolean(false);
    private PipedInputStream pis = null;

    public AvvisaConsumatori(PipedInputStream pis) {
        this.pis = pis;
    }

    public void run() {
        isRunning.set(true);
        // Inizio il canale di Comunicazione

        ObjectInputStream ois = null;
        try {
            ois = new ObjectInputStream(pis);
        } catch (IOException e) {
            e.printStackTrace();
        }

        while (isRunning.get()) {
            // leggo messaggi dal main
            Warning warning = null;
            try {
                warning = (Warning) ois.readObject();
                if (warning.getMessage().equals("fine")) {
                    isRunning.set(false);
                }
            } catch (ClassNotFoundException | IOException e) {
                e.printStackTrace();
            }
            System.out.println("AvvisaConsumatori--- valore: " + + warning.getValore() 
            + " " + warning.getMessage());
        }
    }
    
}